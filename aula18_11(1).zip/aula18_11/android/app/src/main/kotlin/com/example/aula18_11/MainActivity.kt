package com.example.aula18_11

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
