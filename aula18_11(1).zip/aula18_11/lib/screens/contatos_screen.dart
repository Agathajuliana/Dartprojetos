import 'package:flutter/material.dart';
import 'formulario_contato.dart'; // Importa o formulário como componente separado

class ContatosScreen extends StatefulWidget {
  @override
  _ContatosScreenState createState() => _ContatosScreenState();
}

class _ContatosScreenState extends State<ContatosScreen> {
  final List<Map<String, String>> contatos = [
    {"name": "Romain", "email": "romain.hoogmed@example.com"},
    {"name": "Emilie", "email": "emillie.olsen@example.com"},
    {"name": "Téo", "email": "téo.lefevre@xample.com"},
    {"name": "Nicole", "email": "nicole.cruz@example.com"},
    {"name": "Ramna", "email": "ramna.peixoto@example.com"},
    {"name": "Jose", "email": "jose.ortiz@example.com"},
    {"name": "Alma", "email": "alma.christensen@example.com"},
    {"name": "Sergio", "email": "sergio.hill@example.com"},
    {"name": "Malo", "email": "malo.gonzalez@example.com"}
  ];

  void _addContact(String name, String email) {
    setState(() {
      contatos.add({"name": name, "email": email});
    });
    Navigator.of(context).pop(); // Fecha o modal do formulário
  }

  void _showForm() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return FormularioContato(onSubmit: _addContact);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Contatos'),
      ),
      body: ListView.builder(
        itemCount: contatos.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: CircleAvatar(
              child: Text(contatos[index]['name']![0]),
            ),
            title: Text(contatos[index]['name']!),
            subtitle: Text(contatos[index]['email']!),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showForm,
        child: Icon(Icons.add),
      ),
    );
  }
}
