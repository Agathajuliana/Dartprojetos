import 'package:flutter/material.dart';

class ContatoListTile extends StatelessWidget {
  final Map<String, String> contato;

  ContatoListTile({required this.contato});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(
        child: Text(contato['name']![0]),
      ),
      title: Text(contato['name']!),
      subtitle: Text(contato['email']!),
    );
  }
}
