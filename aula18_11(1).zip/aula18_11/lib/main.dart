import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ContatosScreen(),
    );
  }
}

class ContatosScreen extends StatefulWidget {
  @override
  _ContatosScreenState createState() => _ContatosScreenState();
}

class _ContatosScreenState extends State<ContatosScreen> {
  final List<Map<String, String>> contatos = [
    {"name": "Romain", "email": "romain.hoogmed@example.com"},
    {"name": "Emilie", "email": "emillie.olsen@example.com"},
    {"name": "Téo", "email": "téo.lefevre@xample.com"},
    {"name": "Nicole", "email": "nicole.cruz@example.com"},
    {"name": "Ramna", "email": "ramna.peixoto@example.com"},
    {"name": "Jose", "email": "jose.ortiz@example.com"},
    {"name": "Alma", "email": "alma.christensen@example.com"},
    {"name": "Sergio", "email": "sergio.hill@example.com"},
    {"name": "Malo", "email": "malo.gonzalez@example.com"}
  ];

  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  void _addContact() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        contatos.add({
          "name": _nameController.text,
          "email": _emailController.text,
        });
      });
      Navigator.of(context).pop(); // Fecha o modal do formulário
      _nameController.clear();
      _emailController.clear();
    }
  }

  void _showForm() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 16,
            right: 16,
            top: 16,
          ),
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Adicionar Contato',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16),
                  TextFormField(
                    controller: _nameController,
                    decoration: InputDecoration(
                      labelText: 'Nome',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Por favor, insira o nome';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 16),
                  TextFormField(
                    controller: _emailController,
                    decoration: InputDecoration(
                      labelText: 'E-mail',
                      border: OutlineInputBorder(),
                    ),
                    keyboardType: TextInputType.emailAddress,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Por favor, insira o e-mail';
                      }
                      if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                        return 'Por favor, insira um e-mail válido';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _addContact,
                    child: Text('Adicionar'),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Contatos'),
      ),
      body: ListView.builder(
        itemCount: contatos.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: CircleAvatar(
              child: Text(contatos[index]['name']![0]),
            ),
            title: Text(contatos[index]['name']!),
            subtitle: Text(contatos[index]['email']!),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showForm,
        child: Icon(Icons.add),
      ),
    );
  }
}
