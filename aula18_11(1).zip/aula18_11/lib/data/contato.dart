class Contato {
  String name;
  String email;

  Contato({required this.name, required this.email});
}
